Supplementary material to the article "Spline regression with automatic knot
selection"
Authors: Vivien Goepp, Olivier Bouaziz, and Grégory Nuel
Maintainter: Vivien Goepp (vivien.goepp@gmail.com)
Copyright (C) 2019 Vivien Goepp, Olivier Bouaziz, and Grégory Nuel

This supplementary material includes the following files:

1. Code to reproduce the simulations and data applications in the article:
	- "hetero_simu.R" and "homo_simu.R" are the scripts to run the simulations
	  with heteroscedastic errors and homoscedastic errors respectively.
	- "real_data_helmet.R", "real_data_bladder.R", "real_data_lidar.R", and
	  "real_data_coal.R" are the scripts to run the real data applications of
	  the article.

2. The data sets used in the real data applications are provided in csv
format. They correspond to the file "helmet.csv", "bladder.csv", "lidar.csv",
and "coal.csv".

3. The file "appendix.pdf" is an Appendix to the article. It contains a
complementary simulation study comparing A-splines to P-splines.

4. The file "aspline-master.zip" contains the R package containing the A-spline
regression method. Please use the vignette for an easy use-case of the aspline
method. The latest version of this package can be found at
https://github.com/goepp/aspline.
