rm(list = ls())
library(tidyverse)
library(lattice)
library(bandsolve)
library(splines)
library(Rcpp)
library(microbenchmark)
library(devtools)
library(splines2)
library(aspline)

## Parameters
data(coal)
x <- coal$year
y <- coal$n
x_seq <- seq(min(x), max(x), 0.01)

## FIT ASPLINE
n <- length(x)
knots <- seq(x[1] + diff(x)[1] / 2,
             x[n] - diff(x)[1] / 2,
             7)
knots <- seq(x[1] + diff(x)[1] * 5 / 2,
             x[n] - diff(x)[1] * 5 / 2,
             7)
degree <- 3

X <- bSpline(x, knots = knots, intercept = TRUE, degree = degree)
pen <- 10 ^ seq(-6, 6, length = 15)
comp <- block_design(X, degree)
B <- comp$B
alpha <- comp$alpha
old_par <- rep(1, ncol(X))
par <- old_par
w <- rep(1, ncol(X) - degree - 1)
family <- "poisson"

## Aridge
diff <- degree + 1
epsilon = 1e-5
tol = 1e-6
pen <- 10 ^ seq(-1, 1, length  = 40)
aridge <- aridge_solver_glm_slow(X, y, pen, degree, family, maxiter = 1000,
                       epsilon = 1e-2, verbose = FALSE, diff = degree + 1,
                       tol = 1e-6)
pen_index <- which.min(aridge$ebic) - 2
a_fit <- lm(y ~ bSpline(x, knots = aridge$knots_sel[[pen_index]]))
X_seq <- bSpline(x_seq, knots = aridge$knots_sel[[pen_index]], intercept = TRUE)
a_basis <- (X_seq %*% diag(coef(a_fit))) %>%
  as.data.frame() %>%
  mutate(x = x_seq) %>%
  reshape2::melt(id.vars = "x", variable.name = "spline_n", value.name = "y") %>%
  as_tibble() %>%
  filter(y != 0)
a_predict <- tibble(x = x_seq, pred = predict(a_fit, data.frame(x = x_seq)))

## P-SPLINES
p_fit <- mgcv::gam(y ~ s(x, bs = "ps", k = length(knots) + 3 + 1, m = c(3, 2)),
                   family = "poisson")
X <- bSpline(x_seq, knots = knots, intercept = TRUE)
p_basis <- (X %*% diag(coef(p_fit))) %>%
  exp() %>%
  as.data.frame() %>%
  mutate(x = x_seq) %>%
  reshape2::melt(id.vars = "x", variable.name = "spline_n", value.name = "y") %>%
  as_tibble() %>%
  filter(y != 0)
p_predict <- tibble(x = x_seq, pred = predict(p_fit, data.frame(x = x_seq)) %>% exp())

## Plot
ribbon_coal <- bind_rows(old = coal,
                     new = coal %>% mutate(n = lag(n)),
                     .id = "source") %>%
  arrange(year, source)
ggplot() +
  geom_ribbon(data = ribbon_coal, aes(x = year, ymin = 0, ymax = n), fill = "gray") +
  geom_segment(data = coal, aes(x = year, xend = year, y = 0, yend = n),
               size = 0.3, alpha = 1, colour = "darkgray") +
  geom_line(data = a_predict, aes(x, pred), size = 0.5) +
  geom_line(data = p_predict, aes(x, pred), size = 0.5, linetype = 2) +
  geom_segment(aes(x = aridge$knots_sel[[pen_index]],
                   xend = aridge$knots_sel[[pen_index]],
                   y = 0,
                   yend = 6), size = 0.5) +
  theme(legend.position = "none") +
  ylab("") +
  xlab("")
