rm(list = ls())
library(changepoint.np)
library(tidyverse)
library(lattice)
library(bandsolve)
library(splines)
library(Rcpp)
library(microbenchmark)
library(devtools)
library(splines2)
# install_github('goepp/aspline')
library(aspline)

## Load data
data(bladder)
x <- bladder$x
y <- bladder$y

## Fit A-spline
# Parameters
k <- 60
knots <- seq(min(x), max(x), length = k + 2)[-c(1, k + 2)]
pen <- 10 ^ seq(-4, 4, 0.25)
x_seq <- seq(min(x), 500, length = 1000)
degree <- 0

# Fit
aridge <- aridge_solver(x, y, knots, pen, degree = degree)
pen_index <- which.min(aridge$ebic)
a_fit <- lm(y ~ bSpline(x, knots = aridge$knots_sel[[pen_index]], degree = degree))
X_seq <- bSpline(x_seq, knots = aridge$knots_sel[[pen_index]], intercept = TRUE, degree = degree)
a_basis <- (X_seq %*% diag(coef(a_fit))) %>%
  as.data.frame() %>%
  mutate(x = x_seq) %>%
  reshape2::melt(id.vars = "x", variable.name = "spline_n", value.name = "y") %>%
  as_tibble() %>%
  filter(y != 0)
a_predict <- tibble(x = x_seq, pred = predict(a_fit, data.frame(x = x_seq))) %>% slice(-length(x_seq))
ggplot() +
  geom_point(data = data_frame(x = x, y = y), aes(x, y), shape = 1, alpha = 1) +
  geom_line(data = a_predict, aes(x, pred), size = 0.5) +
  # geom_line(data = a_basis, aes(x, y, group = spline_n), linetype = 1, size = 0.1) +
  theme(legend.position = "none") +
  ylab("") +
  xlab("")

## Comparision with changepoint detection method
out <- cpt.np(y, method = "PELT", minseglen = 5, nquantiles = 4 * log(length(y)))
extract_segment <- function(ind, changepoint, data) {
  changepoint <- c(1, changepoint, length(data))
  data[changepoint[ind]:changepoint[ind + 1]]
}
segmented_data <- sapply(1:(length(cpts(out)) + 1),
                         extract_segment, changepoint = cpts(out),
                         data = y)
segment_mean <- sapply(segmented_data, mean)
set_value <- function(ind, x_seq, value, changepoint, data) {
  changepoint <- c(1, changepoint, length(data))
  ypred <- x_seq * 0
  ypred[which(x_seq >= changepoint[ind] & x_seq < changepoint[ind + 1])] <- value[ind]
  ypred
}
temp <- lapply(1:(length(cpts(out)) + 1),
       set_value, x_seq = x_seq, value = segment_mean,
       changepoint = cpts(out), data = x) %>%
  unlist() %>%
  matrix(., nrow = length(x_seq)) %>%
  apply(., 1, sum)
changepoint_predict <- tible(x = x_seq, pred = temp)

# Plot the two fits
ggplot() +
  geom_point(data = data_frame(x = x, y = y), aes(x, y), shape = 1, alpha = 0.5) +
  geom_line(data = a_predict, aes(x, pred), size = 0.5) +
  geom_line(data = changepoint_predict, aes(x, pred), linetype = 2, size = 0.5) +
  theme(legend.position = "none") +
  ylab("") +
  xlab("")
