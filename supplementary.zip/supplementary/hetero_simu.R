library(tidyverse)
library(splines2) # manipulate B-splines
library(mgcv) # P-splines
library(parallel) # parallel computing
library(freeknotsplines) # Spiriti's genetic algorithm
library(aspline) # A-spline

## Download the R implementation of BARS at the URL:
## https://www.jstatsoft.org/article/view/v026i01
dyn.load("barsN.so", now = F)
source("barsN_Rwrapper.R")

# Number of repetitions of simulations
n_rep <- 5 # For illustration purposes
# n_rep <- 500 # Warning: takes a long time to compute

set.seed(0) # for reproducible results

# Define simulation design for heteroscedastic errors
design_hetero <- expand.grid(
  "sample_size" = c(100, 200, 400, 800),
  "sigma" = c(1),
  "ind_rep" = 1:n_rep,
  "k" = 40,
  "fun" = c("bump", "spa_het"),
  "method" = c("p",
               "a_aic", "a_ebic", "a_ebic",
               # "bars", # Uncomment this line only if you have loaded barsN.so and barsN_Rwrapper.R
               "fks"),
  "error" = "hetero",
  stringsAsFactors = FALSE) %>%
  as_tibble() %>%
  mutate(ind_wrapper = 1:nrow(.))
data_hetero <- mclapply(1:nrow(design_hetero), gen_data_hetero, design = design_hetero,
                        mc.cores = detectCores() - 1, mc.preschedule = FALSE) %>%
  do.call(rbind, .)

error_wrapper <- function(ind, design_hetero, data) {
  sample <- data %>% dplyr::filter(ind_wrapper == ind)
  c(ind_wrapper = ind,
    mse =  l2_fit(sample$x, sample$y, sample$k[1], sample$method[1], sample$fun[1])
  )
}
# Test run with the first sample
l2 <- mclapply(1:200, error_wrapper, design_hetero, data_hetero,
                mc.cores = detectCores() - 1, mc.preschedule = FALSE) %>%
  do.call(rbind, .)
## Whole simulation run
## Warning: takes a long time to run
# l2 <- mclapply(1:nrow(design_hetero), error_wrapper, design_hetero, data,
#                mc.cores = detectCores() - 1, mc.preschedule = FALSE) %>%
#   do.call(rbind, .)

# hetero <- left_join(l2, design_hetero, by = "ind_wrapper")
ggplot(hetero %>%
         filter(method %in% c("a_aic", "a_bic", "a_ebic")),
       aes(as.factor(sample_size), mse, color = method, linetype = method)) +
  geom_boxplot() +
  scale_y_log10() +
  facet_wrap(~fun)
ggplot(hetero %>%
         filter(method %in% c("a_ebic", "p")),
       aes(as.factor(sample_size), mse, color = method, linetype = method)) +
  geom_boxplot() +
  scale_y_log10() +
  facet_wrap(~fun)
ggplot(hetero %>%
         filter(method %in% c("a_ebic", "bars", "fks")),
       aes(as.factor(sample_size), mse, color = method, linetype = method)) +
  geom_boxplot() +
  scale_y_log10() +
  facet_wrap(~fun)
