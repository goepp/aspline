library(tidyverse)
library(splines2) # manipulate B-splines
library(mgcv) # P-splines
library(parallel) # parallel computing
library(freeknotsplines) # Spiriti's genetic algorithm
library(aspline) # A-spline

## Download the R implementation of BARS at the URL:
## https://www.jstatsoft.org/article/view/v026i01
dyn.load("barsN.so", now = F)
source("barsN_Rwrapper.R")

n_rep <- 10
## Set n_rep = 500 for the whole simulation
## Warning: simulations take a long time to run
# n_rep <- 500

set.seed(0)
design <- expand.grid("sample_size" = c(100, 200, 400, 800),
                      "sigma" = c(0.15),
                      "ind_rep" = 1:n_rep,
                      "k" = 40,
                      "fun" = c("logit", "sine3"),
                      "method" = c("p", "a_aic",
                                   "a_ebic", "a_ebic",
                                   # "bars",
                                   "fks"),
                      stringsAsFactors = FALSE) %>%
  as_tibble() %>%
  mutate(ind_wrapper = 1:nrow(.))
data <- mclapply(1:nrow(design), gen_data, design = design,
                 mc.cores = detectCores() - 1, mc.preschedule = FALSE) %>%
  do.call(rbind, .)
error_wrapper <- function(ind, design, data) {
  sample <- data %>% filter(ind_wrapper == ind)
  c(ind_wrapper = ind,
    mse =  l2_fit(sample$x, sample$y, sample$k[1], sample$method[1], sample$fun[1])
  )
}
# Test run with the first sample
(l2 <- mclapply(1:1, error_wrapper, design, data,
                mc.cores = detectCores() - 1, mc.preschedule = FALSE))

## Whole simulation run
## Warning: takes a long time to run
# l2 <- mclapply(1:nrow(design), error_wrapper, design, data,
#                mc.cores = detectCores() - 1, mc.preschedule = FALSE) %>%
#   do.call(rbind, .) %>%
#   as_data_frame()

# hetero <- left_join(l2, design, by = "ind_wrapper")
ggplot(hetero %>%
         filter(method %in% c("a_aic", "a_bic", "a_ebic")),
       aes(as.factor(sample_size), mse, color = method, linetype = method)) +
  geom_boxplot() +
  scale_y_log10() +
  facet_wrap(~fun)
ggplot(hetero %>%
         filter(method %in% c("a_ebic", "p")),
       aes(as.factor(sample_size), mse, color = method, linetype = method)) +
  geom_boxplot() +
  scale_y_log10() +
  facet_wrap(~fun)
ggplot(hetero %>%
         filter(method %in% c("a_ebic", "bars", "fks")),
       aes(as.factor(sample_size), mse, color = method, linetype = method)) +
  geom_boxplot() +
  scale_y_log10() +
  facet_wrap(~fun)
