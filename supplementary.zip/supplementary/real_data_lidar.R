library(tidyverse)
library(earth)
library(bandsolve)
library(Rcpp)
library(devtools)
library(splines2)
# install_github('goepp/aspline')
library(aspline)

## Load data
data(lidar)
x <- lidar$range
y <- lidar$logratio

## Fit A-spline
k <- 100
knots <- seq(min(x), max(x), length = k + 2)[-c(1, k + 2)]
pen <- 10 ^ seq(-4, 4, 0.25)
x_seq <- seq(min(x), max(x), 0.01)
degree <- 1
aridge <- aridge_solver(x, y, knots, pen, degree = degree)
a_fit <- lm(y ~ bSpline(x, knots = aridge$knots_sel[[which.min(aridge$ebic)]], degree = degree))
X_seq <- bSpline(x_seq, knots = aridge$knots_sel[[which.min(aridge$ebic)]], intercept = TRUE, degree = degree)
a_basis <- (X_seq %*% diag(coef(a_fit))) %>%
  as.data.frame() %>%
  mutate(x = x_seq) %>%
  reshape2::melt(id.vars = "x", variable.name = "spline_n", value.name = "y") %>%
  as_tibble() %>%
  filter(y != 0)
a_predict <- tibble(x = x_seq, pred = predict(a_fit, data.frame(x = x_seq)))

# Fit MARS
res <- earth(y ~ x)

# Comparision A-spline vs MARS
ggplot() +
  geom_point(data = lidar, aes(range, logratio), shape = 1) +
  geom_line(data = a_predict, aes(x, pred), size = 0.5) +
  geom_line(data = tibble(x = x, pred = res$fitted.values %>% as.vector()), aes(x, pred),
            linetype = 2, size = 0.5) +
  theme(legend.position = "none") +
  ylab("") +
  xlab("")
