library(tidyverse)
library(bandsolve)
library(devtools)
library(splines2)
# install_github('goepp/aspline')
library(aspline)

## Download the R implementation of BARS at the URL:
## https://www.jstatsoft.org/article/view/v026i01
dyn.load("barsN.so", now = F)
source("barsN_Rwrapper.R")

## Load data
data(helmet)
x <- helmet$x
y <- helmet$y

## Fit A-spline
k <- 50
knots <- seq(min(x), max(x), length = k + 2)[-c(1, k + 2)]
knots <- knots[unique(cut(x, breaks = knots, labels = FALSE) %>% na.omit())]
pen <- 10 ^ seq(-8, 3, 0.05)
x_seq <- seq(min(x), max(x), length = 1000)
aridge <- aridge_solver(x, y, knots, pen)
a_fit <- lm(y ~ bSpline(x, knots = aridge$knots_sel[[which.min(aridge$ebic)]]))

X_seq <- bSpline(x_seq, knots = aridge$knots_sel[[which.min(aridge$ebic)]], intercept = TRUE)
a_predict <- tibble(x = x_seq, pred = predict(a_fit, data.frame(x = x_seq)))
a_basis <- (X_seq %*% diag(coef(a_fit))) %>%
  as.data.frame() %>%
  mutate(x = x_seq) %>%
  reshape2::melt(id.vars = "x", variable.name = "spline_n", value.name = "y") %>%
  as_tibble() %>%
  filter(y != 0)
ggplot() +
  geom_point(data = helmet, aes(x, y), shape = 1) +
  geom_line(data = a_predict, aes(x, pred), size = 0.5) +
  geom_line(data = a_basis, aes(x, y, group = spline_n), linetype = 1, size = 0.1) +
  theme(legend.position = "none") +
  ylab("") +
  xlab("")

## BARS
bars_fit <- approxfun(x, barsN.fun(x, y, priorparam = c(1, 40))$postmodes)
bars_predict <- tibble(x = x_seq, pred = bars_fit(x_seq))

## Comparision: A-spline vs BARS
ggplot() +
  geom_point(data = helmet, aes(x, y), shape = 1) +
  geom_line(data = a_predict, aes(x, pred), size = 0.5) +
  geom_point(data = data_frame(x = aridge$knots_sel[[which.min(aridge$ebic)]], y = -147),
             aes(x, y),
             shape = 6) +
  geom_line(data = a_basis, aes(x, y, group = spline_n), linetype = 1, size = 0.1) +
  theme(legend.position = "none") +
  ylab("") +
  xlab("")
ggplot() +
  geom_line(data = bars_predict, aes(x, pred)) +
  geom_point(data = helmet, aes(x, y), shape = 1) +
  theme(legend.position = "none") +
  ylab("") +
  xlab("")

# ## P-SPLINES
# p_fit <- mgcv::gam(y ~ s(x, bs = "ps", k = length(knots) + 3 + 1, m = c(3, 2)))
# X <- bSpline(x_seq, knots = knots, intercept = TRUE)
# p_basis <- (X %*% diag(coef(p_fit))) %>%
#   as.data.frame() %>%
#   mutate(x = x_seq) %>%
#   reshape2::melt(id.vars = "x", variable.name = "spline_n", value.name = "y") %>%
#   as_tibble() %>%
#   filter(y != 0)
# p_predict <- data_frame(x = x_seq, pred = predict(p_fit, data.frame(x = x_seq)))
# ggplot() +
#   geom_point(data = helmet, aes(x, y), shape = 1) +
#   geom_line(data = p_predict, aes(x, pred), size = 0.5) +
#   geom_line(data = p_basis, aes(x, y, group = spline_n), linetype = 1, size = 0.1) +
#   theme(legend.position = "none") +
#   ylab("") + xlab("")
